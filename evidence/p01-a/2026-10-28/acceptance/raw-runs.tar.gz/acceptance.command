scripts/run_p01_acceptance.sh /home/ray/.cache/saccade-native-trt/10.16.1.11/sdk build-p01-verified

sha256sum -c /home/ray/developer/ai/saccade_v1/build-p01-verified/artifact-replay/artifact.expected.sha256

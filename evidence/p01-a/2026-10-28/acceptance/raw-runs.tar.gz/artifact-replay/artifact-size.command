stat -c %s %n /home/ray/.cache/saccade-v1/p01-a/artifact/yolo26s.onnx

git status --porcelain

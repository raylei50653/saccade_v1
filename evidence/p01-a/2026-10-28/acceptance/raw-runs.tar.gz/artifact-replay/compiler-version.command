c++ --version

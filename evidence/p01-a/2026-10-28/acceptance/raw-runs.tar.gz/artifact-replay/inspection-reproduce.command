cmp /home/ray/developer/ai/saccade_v1/build-p01-verified/artifact-replay/inspect.log evidence/p01-a/2026-10-28/artifact/onnx-inspection.tsv

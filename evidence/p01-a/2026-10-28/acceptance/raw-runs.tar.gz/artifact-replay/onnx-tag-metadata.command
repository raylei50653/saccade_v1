curl --fail --location --silent --show-error https://api.github.com/repos/onnx/onnx/git/ref/tags/v1.20.1 -o /home/ray/developer/ai/saccade_v1/build-p01-verified/artifact-replay/onnx-v1.20.1-ref.json

pkg-config --modversion protobuf

cp evidence/p01-a/2026-10-28/artifact/yolo26s.candidate.json /home/ray/developer/ai/saccade_v1/build-p01-verified/artifact-bundle/ 

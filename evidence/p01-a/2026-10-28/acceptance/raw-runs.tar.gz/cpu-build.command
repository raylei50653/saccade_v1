cmake --build /home/ray/developer/ai/saccade_v1/build-p01-verified/cpu --parallel 4 

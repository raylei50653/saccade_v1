cmake -S . -B /home/ray/developer/ai/saccade_v1/build-p01-verified/cpu -DCMAKE_BUILD_TYPE=Release 

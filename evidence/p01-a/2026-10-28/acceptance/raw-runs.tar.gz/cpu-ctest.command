ctest --test-dir /home/ray/developer/ai/saccade_v1/build-p01-verified/cpu --verbose 

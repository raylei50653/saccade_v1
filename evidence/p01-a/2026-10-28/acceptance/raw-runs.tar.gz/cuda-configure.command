cmake -S . -B /home/ray/developer/ai/saccade_v1/build-p01-verified/cuda -DCMAKE_BUILD_TYPE=Release -DSACCADE_ENABLE_CUDA=ON -DCMAKE_CUDA_COMPILER=/opt/cuda/bin/nvcc -DCMAKE_CUDA_ARCHITECTURES=120 

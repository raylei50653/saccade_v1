bash -c uname\ -a\;\ cmake\ --version\;\ c++\ --version\;\ /opt/cuda/bin/nvcc\ --version\;\ nvidia-smi\ --query-gpu=name\,uuid\,driver_version\,memory.total\ --format=csv 

cmake -S . -B /home/ray/developer/ai/saccade_v1/build-p01-verified/missing-sdk -DSACCADE_ENABLE_TENSORRT=ON -DSACCADE_TENSORRT_ROOT=/home/ray/developer/ai/saccade_v1/build-p01-verified/absent-sdk 

cp /home/ray/.cache/saccade-v1/p01-a/artifact/yolo26s.onnx /home/ray/developer/ai/saccade_v1/build-p01-verified/artifact-bundle/ 

sha256sum -c evidence/cuda-synthetic/2026-10-28-closeout/SHA256SUMS 

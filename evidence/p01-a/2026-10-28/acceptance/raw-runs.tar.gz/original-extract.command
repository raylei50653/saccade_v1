tar -xzf evidence/cuda-synthetic/2026-10-28-closeout/raw-runs.tar.gz -C /home/ray/developer/ai/saccade_v1/build-p01-verified/baseline 

git status --porcelain 

cmake --build /home/ray/developer/ai/saccade_v1/build-p01-verified/trt --parallel 4 

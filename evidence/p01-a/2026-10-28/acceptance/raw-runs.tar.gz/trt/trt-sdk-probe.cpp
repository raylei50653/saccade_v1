#include <NvInfer.h>
#include <cuda_runtime_api.h>
#include <iostream>
static_assert(NV_TENSORRT_MAJOR == 10 && NV_TENSORRT_MINOR == 16 && NV_TENSORRT_PATCH == 1 && NV_TENSORRT_BUILD == 11,
              "native TensorRT headers must be 10.16.1.11");
int main() {
  int runtime = 0, driver = 0;
  cudaDeviceProp gpu{};
  if (getInferLibVersion() != NV_TENSORRT_VERSION || getInferLibBuildVersion() != NV_TENSORRT_BUILD) {
    std::cerr << "TensorRT header/library version mismatch (requires 10.16.1.11)\n"; return 1;
  }
  if (cudaRuntimeGetVersion(&runtime) != cudaSuccess || runtime < 13020 || runtime >= 14000 ||
      cudaDriverGetVersion(&driver) != cudaSuccess || driver < runtime ||
      cudaGetDeviceProperties(&gpu, 0) != cudaSuccess || gpu.major < 7 || (gpu.major == 7 && gpu.minor < 5)) {
    std::cerr << "CUDA runtime/driver/GPU unavailable or incompatible: runtime=" << runtime << " driver=" << driver << '\n'; return 2;
  }
  std::cout << "TensorRT=" << getInferLibVersion() << " CUDA runtime=" << runtime << " driver=" << driver
            << " GPU=" << gpu.name << " SM=" << gpu.major << '.' << gpu.minor << '\n';
}

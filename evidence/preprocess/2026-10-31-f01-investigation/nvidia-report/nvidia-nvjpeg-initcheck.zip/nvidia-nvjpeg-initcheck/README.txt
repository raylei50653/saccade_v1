nvJPEG HARDWARE backend: initcheck reports uninitialized reads in nvjpeg::rgba2rgb

Files
- repro.cu                 standalone repro (CUDA runtime + nvJPEG only)
- baseline.jpg             input: 35x27 baseline 8-bit 4:2:0 JPEG, 1,124 bytes
- baseline.rgb             expected output: planar RGB (3 x 35 x 27 = 2,835 bytes),
                           produced by libjpeg: djpeg -dct int -nosmooth -rgb
- initcheck-full-945.log   full initcheck output for one HARDWARE RGB decode (945 errors)
- identity.log             nvidia-smi, nvcc, compute-sanitizer versions, ldd, hashes
                           (local working directory replaced by <workdir>)
- windows-initcheck-1890.log
                           native Windows initcheck output, two HARDWARE RGB decodes
                           (default --print-limit; 1,890 errors)

Environment
- GeForce RTX 5070 Ti Laptop GPU (SM 12.0)
- WSL2, guest kernel Linux 6.18.33.1-microsoft-standard-WSL2 x86_64
- Driver: KMD 617.42 (nvidia-smi 615.78.08), CUDA UMD 13.4
- CUDA toolkit 13.4.92, Compute Sanitizer 2026.3.0.0
- nvJPEG 13.2.3 (toolkit) and 13.0.1 (switched via LD_LIBRARY_PATH): both reproduce

Native Windows (same GPU and host)
- Windows 11 Pro 10.0.26300 x64, WDDM, driver 617.42
- Windows nvcc 13.4.92, Compute Sanitizer 2026.3.0.0, nvJPEG 13.2.3.58 redist DLL, MSVC 14.44
- Same repro.cu bytes. HARDWARE RGB x2: initcheck 1,890 errors (exit 99) at the same
  rgba2rgb<3> +0x170; memcheck 0; RGB/RGBI exact; NO_PIPELINE / no PreAllocate / RGBI
  still 1,890; Y 108; HYBRID 0; tool positive/negative controls 2,835 / 0.
- Not tested on a native Linux driver.

Build
  nvcc -std=c++20 -O2 -lineinfo -arch=sm_120 -I/opt/cuda/include repro.cu \
    -L/opt/cuda/lib64 -Xlinker -rpath -Xlinker /opt/cuda/lib64 -lnvjpeg -o repro
  (our host compiler additionally required --allow-unsupported-compiler)

Run
  usage: repro hw|hybrid|skip rgb|rgbi|yuv|y|nv12 default|no-pipeline \
               preallocate|no-preallocate uninit|zero|a5 REPEATS JPEG EXPECTED_PLANAR_RGB OUTPUT

  The attached log was produced with:
  compute-sanitizer --tool initcheck --error-exitcode 99 --print-limit 0 \
    ./repro hw rgb default preallocate uninit 1 baseline.jpg baseline.rgb out.bin

  Result: exit 99, "ERROR SUMMARY: 945 errors"; the program itself reports
  rgb_equivalence=exact (output matches baseline.rgb byte for byte).

Useful variants
  ./repro hw rgb default preallocate uninit 2 ...     -> initcheck 1,890 errors, output exact
  ./repro hybrid rgb default preallocate uninit 2 ... -> initcheck 0 errors
  ./repro hw y   default preallocate uninit 2 ...     -> errors on SDK-internal cuMemcpy2DAsync source
  compute-sanitizer --tool memcheck ./repro hw rgb ... -> 0 errors
